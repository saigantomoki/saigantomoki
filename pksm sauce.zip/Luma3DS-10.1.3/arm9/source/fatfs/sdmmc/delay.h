#pragma once

#include "../../types.h"

void waitcycles(u32 us);
