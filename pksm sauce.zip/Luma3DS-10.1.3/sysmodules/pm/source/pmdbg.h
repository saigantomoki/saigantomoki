#pragma once

#include <3ds/types.h>

void pmDbgHandleCommands(void *ctx);
